# web-231
web 231 coursework
<h1>WEB 231 Enterprise JavaScript I</h1>

<h2>Contributors</h2>

<ul>
  <li> Richard Krasso</li>
  <li>Nadia Gainer</li>
</ul>
